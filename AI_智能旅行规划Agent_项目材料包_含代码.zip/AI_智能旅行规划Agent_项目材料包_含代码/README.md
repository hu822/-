# AI 智能旅行规划 Agent 材料包

本压缩包包含以下文件：

- `项目说明.md`：完整项目说明，包含核心痛点、核心逻辑流、多 Agent 协作和长链推理说明。
- `精简版.txt`：适合直接填写到表单中的简洁版本。
- `code/travel_agent_demo.py`：Python 演示代码，模拟智能旅行规划 Agent 的核心流程。
- `code/sample_input.json`：示例输入。
- `code/README_code.md`：代码运行说明。
- `code/requirements.txt`：依赖说明，本示例不依赖第三方库。

建议先阅读 `精简版.txt`，如果需要展示项目完整性，再结合 `项目说明.md` 和 `code` 文件夹中的代码。
