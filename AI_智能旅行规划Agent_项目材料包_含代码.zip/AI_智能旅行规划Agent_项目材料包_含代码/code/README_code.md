# 代码说明

`travel_agent_demo.py` 是一个简化版 AI 智能旅行规划 Agent 示例。

## 运行方式

```bash
python travel_agent_demo.py
```

## 代码结构

- `RequirementParser`：解析用户自然语言需求。
- `RoutePlanningAgent`：生成每日路线。
- `BudgetAgent`：估算预算并检查是否超支。
- `TrafficAgent`：生成交通建议。
- `ExperienceAgent`：检查行程体验。
- `TravelPlannerAgent`：主控 Agent，负责协调多个子 Agent。

该代码不调用外部 API，主要用于展示 Agent 的核心逻辑流。实际项目中可以接入地图 API、酒店 API、票务 API 和大语言模型 API。
