"""
AI 智能旅行规划 Agent 演示代码

说明：
1. 该示例不依赖任何外部 API，只用于展示 Agent 的核心逻辑流。
2. 实际项目中，可以将景点数据库替换为地图 API、旅游平台 API 或 LLM 检索结果。
3. 代码模拟了“主 Agent + 多个子 Agent”的协作流程。
"""

from __future__ import annotations

from dataclasses import dataclass, field
import re
from typing import Dict, List, Tuple


# =========================
# 1. 数据结构定义
# =========================

@dataclass
class UserRequest:
    destination: str
    days: int
    budget: float
    people: int
    interests: List[str]
    pace: str = "normal"


@dataclass
class Attraction:
    name: str
    area: str
    tags: List[str]
    duration_hours: float
    ticket_price: float
    priority: int


@dataclass
class DailyPlan:
    day: int
    attractions: List[Attraction]
    traffic_tip: str = ""
    experience_tip: str = ""


@dataclass
class TravelPlan:
    request: UserRequest
    daily_plans: List[DailyPlan]
    estimated_cost: Dict[str, float]
    warnings: List[str] = field(default_factory=list)


# =========================
# 2. 简化景点数据库
# =========================

ATTRACTION_DB: Dict[str, List[Attraction]] = {
    "重庆": [
        Attraction("解放碑", "渝中", ["城市", "美食", "购物"], 2.0, 0, 9),
        Attraction("洪崖洞", "渝中", ["夜景", "地标", "美食"], 2.5, 0, 10),
        Attraction("长江索道", "渝中", ["城市", "交通体验", "夜景"], 1.5, 30, 8),
        Attraction("磁器口古镇", "沙坪坝", ["历史", "美食", "古镇"], 3.0, 0, 8),
        Attraction("李子坝轻轨站", "渝中", ["城市", "拍照"], 1.0, 0, 7),
        Attraction("南山一棵树", "南岸", ["夜景", "观景"], 2.0, 30, 9),
        Attraction("重庆动物园", "九龙坡", ["亲子", "休闲"], 3.0, 25, 7),
        Attraction("四川美术学院", "沙坪坝", ["艺术", "拍照"], 2.0, 0, 6),
        Attraction("鹅岭二厂", "渝中", ["文创", "拍照", "休闲"], 2.0, 0, 7),
    ],
    "成都": [
        Attraction("宽窄巷子", "青羊", ["历史", "美食", "街区"], 2.5, 0, 9),
        Attraction("锦里", "武侯", ["历史", "美食", "夜景"], 2.0, 0, 8),
        Attraction("武侯祠", "武侯", ["历史", "文化"], 2.0, 50, 8),
        Attraction("成都大熊猫繁育研究基地", "成华", ["亲子", "动物", "自然"], 4.0, 55, 10),
        Attraction("太古里", "锦江", ["城市", "购物", "美食"], 2.0, 0, 7),
        Attraction("人民公园", "青羊", ["休闲", "茶馆"], 2.0, 0, 7),
    ],
    "北京": [
        Attraction("故宫", "东城", ["历史", "文化"], 4.0, 60, 10),
        Attraction("天安门广场", "东城", ["历史", "地标"], 1.5, 0, 9),
        Attraction("颐和园", "海淀", ["历史", "自然"], 4.0, 30, 9),
        Attraction("八达岭长城", "延庆", ["历史", "自然"], 5.0, 40, 10),
        Attraction("南锣鼓巷", "东城", ["美食", "街区"], 2.0, 0, 7),
        Attraction("什刹海", "西城", ["夜景", "休闲"], 2.0, 0, 7),
    ],
}


# =========================
# 3. 需求理解 Agent
# =========================

class RequirementParser:
    """将用户自然语言需求转化为结构化约束。"""

    def parse(self, text: str) -> UserRequest:
        destination = self._extract_destination(text)
        days = self._extract_days(text)
        budget = self._extract_budget(text)
        people = self._extract_people(text)
        interests = self._extract_interests(text)
        pace = self._extract_pace(text)

        return UserRequest(
            destination=destination,
            days=days,
            budget=budget,
            people=people,
            interests=interests,
            pace=pace,
        )

    def _extract_destination(self, text: str) -> str:
        for city in ATTRACTION_DB:
            if city in text:
                return city
        return "重庆"

    def _extract_days(self, text: str) -> int:
        match = re.search(r"(\d+)\s*天", text)
        return int(match.group(1)) if match else 3

    def _extract_budget(self, text: str) -> float:
        match = re.search(r"预算\s*(\d+)", text)
        return float(match.group(1)) if match else 3000.0

    def _extract_people(self, text: str) -> int:
        match = re.search(r"(\d+)\s*个人", text)
        return int(match.group(1)) if match else 2

    def _extract_interests(self, text: str) -> List[str]:
        keywords = ["美食", "夜景", "历史", "文化", "亲子", "自然", "购物", "拍照", "休闲", "艺术"]
        interests = [kw for kw in keywords if kw in text]
        return interests if interests else ["城市", "美食"]

    def _extract_pace(self, text: str) -> str:
        if "不要太赶" in text or "轻松" in text or "慢" in text:
            return "relaxed"
        if "紧凑" in text or "多玩" in text:
            return "compact"
        return "normal"


# =========================
# 4. 路线规划 Agent
# =========================

class RoutePlanningAgent:
    """根据兴趣、优先级和区域相近性生成每日路线。"""

    def plan_route(self, request: UserRequest) -> List[DailyPlan]:
        attractions = ATTRACTION_DB.get(request.destination, ATTRACTION_DB["重庆"])
        ranked = sorted(
            attractions,
            key=lambda a: (self._interest_score(a, request.interests), a.priority),
            reverse=True,
        )

        max_hours = {
            "relaxed": 6.0,
            "normal": 8.0,
            "compact": 10.0,
        }[request.pace]

        used = set()
        daily_plans: List[DailyPlan] = []

        for day in range(1, request.days + 1):
            day_items: List[Attraction] = []
            current_hours = 0.0
            preferred_area = None

            for item in ranked:
                if item.name in used:
                    continue

                # 优先把同一区域的景点放在同一天，减少跨区域移动。
                area_bonus = preferred_area is None or item.area == preferred_area
                if current_hours + item.duration_hours <= max_hours or area_bonus:
                    if current_hours + item.duration_hours <= max_hours:
                        day_items.append(item)
                        used.add(item.name)
                        current_hours += item.duration_hours
                        preferred_area = preferred_area or item.area

                if current_hours >= max_hours * 0.85:
                    break

            daily_plans.append(DailyPlan(day=day, attractions=day_items))

        return daily_plans

    def _interest_score(self, attraction: Attraction, interests: List[str]) -> int:
        return sum(1 for tag in attraction.tags if tag in interests)


# =========================
# 5. 预算 Agent
# =========================

class BudgetAgent:
    """估算行程成本，并判断是否存在预算风险。"""

    def estimate_cost(self, request: UserRequest, daily_plans: List[DailyPlan]) -> Tuple[Dict[str, float], List[str]]:
        ticket_cost = sum(
            item.ticket_price * request.people
            for plan in daily_plans
            for item in plan.attractions
        )

        # 简化估算：住宿按每晚每间计算，两人一间；餐饮和市内交通按人天估算。
        hotel_nights = max(request.days - 1, 1)
        room_count = max((request.people + 1) // 2, 1)

        hotel_cost = hotel_nights * room_count * 350
        food_cost = request.days * request.people * 120
        local_traffic_cost = request.days * request.people * 60

        total = ticket_cost + hotel_cost + food_cost + local_traffic_cost

        cost = {
            "门票": round(ticket_cost, 2),
            "住宿": round(hotel_cost, 2),
            "餐饮": round(food_cost, 2),
            "市内交通": round(local_traffic_cost, 2),
            "合计": round(total, 2),
        }

        warnings = []
        if total > request.budget:
            warnings.append(
                f"预算可能超支：预计 {total:.0f} 元，高于预算 {request.budget:.0f} 元。"
            )
        elif total > request.budget * 0.9:
            warnings.append(
                f"预算接近上限：预计 {total:.0f} 元，建议预留机动资金。"
            )

        return cost, warnings


# =========================
# 6. 交通 Agent
# =========================

class TrafficAgent:
    """根据每日景点区域生成交通建议。"""

    def add_traffic_tips(self, daily_plans: List[DailyPlan]) -> None:
        for plan in daily_plans:
            areas = [item.area for item in plan.attractions]
            unique_areas = list(dict.fromkeys(areas))

            if not unique_areas:
                plan.traffic_tip = "当日暂无景点安排。"
            elif len(unique_areas) == 1:
                plan.traffic_tip = f"当日主要集中在{unique_areas[0]}区域，建议步行、地铁或短途打车结合。"
            else:
                plan.traffic_tip = (
                    f"当日涉及{len(unique_areas)}个区域：{'、'.join(unique_areas)}，"
                    "建议优先使用地铁连接，跨区路段可考虑打车。"
                )


# =========================
# 7. 体验优化 Agent
# =========================

class ExperienceAgent:
    """检查行程强度，给出体验优化建议。"""

    def add_experience_tips(self, request: UserRequest, daily_plans: List[DailyPlan]) -> List[str]:
        warnings: List[str] = []

        for plan in daily_plans:
            total_hours = sum(item.duration_hours for item in plan.attractions)

            if request.pace == "relaxed" and total_hours > 6.5:
                plan.experience_tip = "行程略紧，建议减少一个低优先级景点或增加咖啡/休息时间。"
                warnings.append(f"第 {plan.day} 天行程可能偏紧。")
            elif total_hours < 3:
                plan.experience_tip = "当日安排较轻松，可根据体力增加附近备选景点。"
            else:
                plan.experience_tip = "当日游玩强度适中，整体可执行性较好。"

        return warnings


# =========================
# 8. 主控 Agent
# =========================

class TravelPlannerAgent:
    """主 Agent：协调各子 Agent 完成完整旅行计划。"""

    def __init__(self) -> None:
        self.parser = RequirementParser()
        self.route_agent = RoutePlanningAgent()
        self.budget_agent = BudgetAgent()
        self.traffic_agent = TrafficAgent()
        self.experience_agent = ExperienceAgent()

    def generate_plan(self, user_text: str) -> TravelPlan:
        # Step 1: 理解需求
        request = self.parser.parse(user_text)

        # Step 2: 路线 Agent 生成初始路线
        daily_plans = self.route_agent.plan_route(request)

        # Step 3: 交通 Agent 添加交通建议
        self.traffic_agent.add_traffic_tips(daily_plans)

        # Step 4: 体验 Agent 检查行程强度
        experience_warnings = self.experience_agent.add_experience_tips(request, daily_plans)

        # Step 5: 预算 Agent 估算成本
        estimated_cost, budget_warnings = self.budget_agent.estimate_cost(request, daily_plans)

        # Step 6: 汇总结果
        warnings = experience_warnings + budget_warnings
        return TravelPlan(
            request=request,
            daily_plans=daily_plans,
            estimated_cost=estimated_cost,
            warnings=warnings,
        )


# =========================
# 9. 输出函数
# =========================

def print_plan(plan: TravelPlan) -> None:
    request = plan.request

    print("=" * 60)
    print("AI 智能旅行规划 Agent 输出结果")
    print("=" * 60)
    print(f"目的地：{request.destination}")
    print(f"天数：{request.days} 天")
    print(f"人数：{request.people} 人")
    print(f"预算：{request.budget:.0f} 元")
    print(f"兴趣偏好：{'、'.join(request.interests)}")
    print(f"节奏偏好：{request.pace}")
    print()

    for daily in plan.daily_plans:
        print(f"第 {daily.day} 天")
        if not daily.attractions:
            print("  暂无安排")
        for idx, item in enumerate(daily.attractions, start=1):
            tags = "、".join(item.tags)
            print(
                f"  {idx}. {item.name}（区域：{item.area}，预计 {item.duration_hours} 小时，标签：{tags}）"
            )
        print(f"  交通建议：{daily.traffic_tip}")
        print(f"  体验建议：{daily.experience_tip}")
        print()

    print("预算估算")
    for key, value in plan.estimated_cost.items():
        print(f"  {key}: {value:.2f} 元")

    if plan.warnings:
        print()
        print("风险提示")
        for warning in plan.warnings:
            print(f"  - {warning}")


# =========================
# 10. 运行示例
# =========================

if __name__ == "__main__":
    user_query = "我想去重庆玩3天，预算3000元，两个人，喜欢美食和夜景，希望行程不要太赶。"

    planner = TravelPlannerAgent()
    travel_plan = planner.generate_plan(user_query)
    print_plan(travel_plan)
